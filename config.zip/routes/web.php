<?php
Auth::routes();

Route::get('/', 'HomeController@index')->name('home');

//Articulos
Route::get('articulo','ArticuloController@index')->name('articulo');
Route::get('articulo/buscar','ArticuloController@getArticulo')->name('articulo@buscar');
Route::get('articulo/ultimo','ArticuloController@getUltimo')->name('articulo@ultimo');
Route::put('articulo','ArticuloController@getByCodigo');
Route::post('articulo/res','ArticuloController@reservarCodigo')->name('articulo@reservarCodigo');
Route::put('articulo/{id}','ArticuloController@update')->name('articulo.update');
Route::delete('articulo/res/{id}','ArticuloController@destroy')->name('articulo.destroy');
//STOCK
Route::delete('stock/{id}','StockController@destroy');
Route::post('stock/{id}','StockController@update');
//VENTA
Route::get('infventa','VentaController@indexInf')->name('infventa');
Route::get('infventa/fecha','VentaController@getVentaByFecha')->name('infventa.fecha');
Route::post('infventa/chart','VentaController@getVentaChart')->name('infventa.chart');
Route::get('infventa/detalle/{id}','VentaController@getDetalle');
Route::get('infventa/articulo','VentaController@getVentaArticulo');
Route::get('venta','VentaController@index')->name('venta');
Route::post('venta','VentaController@store');
//CAJA
Route::get('aperturacierre','AperturaController@index')->name('apertura');
Route::post('aperturaciere/open','AperturaController@store')->name('apertura.add');
Route::post('aperturaciere/cierre','AperturaController@update')->name('apertura.close');
Route::get('cierre/{operacion}','AperturaController@indexCierre')->name('cierre');
Route::get('aperturacierre/{sucursal}','AperturaController@getStatu');


Route::get('usuario/all','UserController@showAll')->name('showalluser');
Route::get('v1/unidad/all','UnidadController@All');
Route::get('seccion/all','SeccionController@All');

Route::get('sucursal/all','SucursalController@All');
Route::get('sucursal/set','SucursalController@set')->name('sucursal.set');

Route::get('stock/{id}','StockController@show');

//cliente
Route::get('cliente/buscar','ClienteController@buscar');
