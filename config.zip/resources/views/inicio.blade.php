<!DOCTYPE html>
<html>
<head>
	<title>Softsystem</title>
</head>
<body>
<h1>Inicio</h1>
</body>
</html>