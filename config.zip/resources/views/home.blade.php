@extends('layouts.app')
@section('title','SOFTSYSTEM')
@section('main')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="container d-flex align-items-center justify-content-center">
                    <article class="px-3 py-3">
                        <img src="img/logo-softsystem.PNG">
                        <h2>SOFTSYSTEM WEB</h2> 
                    </article>  
                    
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
