window.Raphael = require('raphael');
window.Morris = require('morris.js');