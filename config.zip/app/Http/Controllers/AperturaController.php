<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Apertura;
use App\Sucursal;
use App\Caja;
use DB;

class AperturaController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(){
    	$sucursales= Sucursal::all();
    	$cajas= Caja::all();
    	$aperturas= Apertura::join('sucursales','apert_cierres_caja.suc_cod','=','sucursales.suc_cod')->join('caja','apert_cierres_caja.caja_cod','=','caja.caja_cod')->orderBy('nro_operacion','DESC')->limit(10)->get();
    	return view('apertura',compact('sucursales','cajas','aperturas'));
    }
    public function indexCierre($operacion){
    	$apertura= Apertura::join('sucursales','apert_cierres_caja.suc_cod','=','sucursales.suc_cod')->join('caja','apert_cierres_caja.caja_cod','=','caja.caja_cod')->orderBy('nro_operacion','DESC')
    		->where("apert_cierres_caja.nro_operacion","=",$operacion)->get();
    	//return $apertura;
    		if(count($apertura)>0){
    			return view('cierre',compact('apertura'));		
    		}else{
    			return redirect()->route('apertura');
    		}
    	
    }
    public function store(Request $request){    	
    	$date= date('Y-m-d');
    	$hora= date('H:i:s');
    	$apertura= new Apertura();
    	$apertura->cod_usuarios= $request->usuario ;
    	$apertura->caja_cod= $request->caja;
    	$apertura->apert_fecha= $date;
    	$apertura->apert_hora= $hora;
    	$apertura->apert_monto= $request->monto;
    	$apertura->apert_estado= 1;
    	$apertura->suc_cod= $request->sucursal;
    	$apertura->save();
    	
    	return redirect()->back();
    }
    public function update(Request $request){
    	$date= date('Y-m-d');
    	$hora= date('H:i:s');
    	Apertura::find($request->nro_operacion)->update(['cierre_fecha'=> $date, 'cierre_hora'=> $hora, 'cierre_monto'=>$request->monto, 'apert_estado'=> '0']);
    	return redirect()->route('apertura');

    }
    public function getStatu($id){
        $date= date('Y-m-d');
        return Apertura::where('apert_cierres_caja.suc_cod','=',$id)
        ->where('apert_cierres_caja.apert_fecha','=',$date)->first();
    }
}
