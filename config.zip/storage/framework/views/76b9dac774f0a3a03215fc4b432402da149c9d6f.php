<?php $__env->startSection('title','Establecer sucursal'); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
	<div class="card">
		<div class="card-header">
			<strong>Establecer Sucursal</strong>
		</div>
		<div class="card-body">
			<ul class="list-inline">
			<?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<label class="font-weight-bold"><input type="radio" value="<?php echo e($sucursal['suc_cod']); ?>" data-descripcion="<?php echo e($sucursal['suc_desc']); ?>" name="sucursal" id="sucursal" class="custom-radio"> <?php echo e($sucursal['suc_desc']); ?></label>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
		</div>
		<div class="card-footer">
			<button class="btn btn-success" onclick="setSucursal()"><span class="fa fa-save"></span> ESTABLECER</button>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	function setSucursal(){
		var obj= document.getElementsByName("sucursal");
		var descripcion= "";
		var id= "";
		for(var i=0; i<obj.length ; i++){ 
			if(obj[i].checked){
				descripcion= obj[i].getAttribute('data-descripcion');
				id= obj[i].value;
				break;
			}
		}
		localStorage.setItem("suc_desc",descripcion);
		localStorage.setItem("suc_cod",id);
		Swal.fire('Informacion!','Se ha esteblecido sucursal!', 'success' );
		window.getSucursal();
	}
	function checkSucursal(){
		var id= localStorage.getItem("suc_cod");
		if(id != null){
			var obj= document.getElementsByName("sucursal");
			for(var i=0; i<obj.length ; i++){
				if(obj[i].value== id){
					obj[i].checked= true;
				}
			}
		}
	}
	checkSucursal();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\softsystem\resources\views/setsucursal.blade.php ENDPATH**/ ?>