<?php $__env->startSection('titulo','Login'); ?>
<?php $__env->startSection('main'); ?>
<br>
<br>
<div class="container d-flex justify-content-center align-items-center" id="app">
	<div class="card">
    	<div class="card-header bg-info text-white">
        	<strong>Iniciar Sesi&oacute;n</strong>
        </div>
	<div class="card-body">
    <template v-if="error">
      <div class="alert alert-warning" role="alert">
        {{ error }}
      </div>
    </template>
    <template v-else> 
      <br>
    </template>
		<div style="padding-left:10px;padding-right:10px;">
		<div id="msg" role="alert">
  &nbsp;</div>
		<div class="input-group">
  			<span class="input-group-prepend">
          <span class="input-group-text">
            <span class="fa fa-user"></span>
          </span>
        </span>
        <select v-model="usuario" class="custom-select">
          <option>Seleccionar</option>
          <template v-for="usuario in usuarios">
            <option v-bind:value="usuario.user_usuarios">
            {{ usuario.nom_usuarios }}
            </option>
          </template>
        </select>
		</div>
		<br>
		<div class="input-group">
  			<span class="input-group-prepend">
          <span class="input-group-text">
            <span class="fa fa-key"></span>  
          </span>
        </span>
  			<input tabindex="2" v-on:keyup.enter="enviar()"  type="password" v-model="password" class="form-control" placeholder="Contraseña">
		</div>		
	</div>
	</div>
	<div class="card-footer">
		<center><button v-on:click="enviar()" class="btn btn-success" ><span class="glyphicon glyphicon-chevron-right"></span>&nbsp;Acceder al Sistema</button></center>
		<span class="text-muted align-items-center">Sistema de Gestion de Stock, Compra, Venta &copy; 2020</span>	
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
	//const axios = require('axios').default;
	var app = new Vue({
  el: '#app',
  data: {
    usuario:'Seleccionar',
  	usuarios:[],
  	password:'',
  	error:''
  },
  methods: {
    getUser:function(){
      var url='<?php echo e(route("showalluser")); ?>';
      axios.get(url)
      .then(response=>{
        this.usuarios= response.data;
      })
      .catch(e=>{
        this.error= e.message;
      })
    },
    enviar: function () {
    	var url='/login';
    	if(this.usuario.length>0 && this.password.length>0){
    		axios.post(url,{
    			user: this.usuario.trim(),
    			password: this.password
    		})
    		.then(response=>{
    			if(response.data.estado==2){
    				this.error= response.data.data;
    			}else{
    				//window.location.href="<?php echo e(route('home')); ?>";
    			}
    		})
    		.catch(e=>{
    			this.error= e.message;
    		});
    	}else{
    		this.error="Complete los campos!";
    	}
    }
  },
  mounted(){
    this.getUser();
  }
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\softsystem\resources\views/login.blade.php ENDPATH**/ ?>