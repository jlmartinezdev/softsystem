<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent("title"); ?></title>
    

    <!-- Scripts -->

      <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/all.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent("style"); ?>
</head>
<body>
    <div>
        <?php if(auth()->guard()->guest()): ?>
            <?php echo $__env->make('partial.sidebar_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php if(Auth::user()->cod_rol == 4): ?>
                <?php echo $__env->make('partial.sidebar_administrador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('partial.sidebar_vendedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>
      
        <br>
        <br>
        <br>
        <main>
            <?php echo $__env->yieldContent('main'); ?>
        </main>
    </div>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <script type="text/javascript">
        function soloNumero(event)
        {
            if(event.charCode >= 48 && event.charCode <= 57)
            { 
              return true;
            }
            return false; 
        }
        function format(input)
        {
            var num = input.value.replace(/\./g,"");
            num = num.toString().split("").reverse().join("").replace(/(?=\d*\.?)(\d{3})/g,'$1.');
            num = num.split("").reverse().join("").replace(/^[\.]/, "");
            input.value = num;   
        }
        function getSucursal(){
            var id= localStorage.getItem("suc_cod");
            var desc= localStorage.getItem("suc_desc");
            if(desc != null){
                var obj= document.getElementById("sucursal");
                obj.setAttribute('data-id',id);
                obj.innerHTML=" "+desc
            }else{
                var obj= document.getElementById("sucursal");
                obj.innerHTML=" Sel. Sucursal"
            }
            
        }
        getSucursal();
    
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\softsystem\resources\views/layouts/app.blade.php ENDPATH**/ ?>