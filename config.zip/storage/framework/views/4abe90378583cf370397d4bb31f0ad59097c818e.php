<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent("titulo","Softsystem"); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(mix('/css/app.css')); ?>">
	<script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>
<body>
	<div id="app" class="d-flex flex-column h-screen justify-content-between">
		<main>
			<?php echo $__env->yieldContent("contenido"); ?>
		</main>
		<footer class="text-center text-secondary">
			<?php echo e(config('app.name')); ?> | Copyright @ <?php echo e(date('Y')); ?>

		</footer>
	</div>
</body>
</html><?php /**PATH C:\laragon\www\softsystem\resources\views/layout.blade.php ENDPATH**/ ?>