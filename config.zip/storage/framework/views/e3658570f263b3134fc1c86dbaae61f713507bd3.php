<?php $__env->startSection('title','Apertura/Cierre de Caja'); ?>
<?php $__env->startSection('main'); ?>
<div id="app">
	<div class="container">
		<div class="card">
			<div class="card-header"><strong>Apertura - Cierre Caja</strong>
			</div>
			<div class="card-body">
				<form method="POST" action="<?php echo e(route('apertura.add')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" value="<?php echo e(Auth::user()->cod_usuarios); ?>" name="usuario">
					<div class="row">
					<div class="col-sm-4">
						<div class="form-group">
						<strong>Sucursal</strong>
						<select class="form-control" name="sucursal" id="selsucursal" required>
							<?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <option value="<?php echo e($sucursal['suc_cod']); ?>"><?php echo e($sucursal['suc_desc']); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>	
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group">
						<strong>Caja</strong>
						<select class="form-control" name="caja" required>
							<?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <option value="<?php echo e($caja['caja_cod']); ?>"><?php echo e($caja['caja_descrip']); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>	
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group">
						<strong>Monto</strong>
						<input type="number" class="form-control" name="monto" placeholder="Monto apertura"  required>	
						</div>
					</div>
				</div>
				
				
						
			</div>
			<div class="card-footer">
				<button type="submit" class="btn btn-success font-weight-bold"><span class="fa fa-lock-open"></span> ABRIR CAJA</button>
			</div>
		</form>
		</div>
		<br>
		<table class="table table-striped table-hover table-sm">
			<tr>
				<th>Nro. Operacion</th>
				<th>Sucursal</th>
				<th>Caja</th>
				<th>Fecha</th>
				<th>Hora</th>
				<th>Estado</th>
				<th>Cerrar </th>

			</tr>
			<?php $__currentLoopData = $aperturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apertura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($apertura['nro_operacion']); ?></td>
				<td><?php echo e($apertura['suc_desc']); ?></td>
				<td><?php echo e($apertura['caja_descrip']); ?></td>
				<td><?php echo e(date('m/d/Y',strtotime($apertura['apert_fecha']))); ?></td>
				<td><?php echo e($apertura['apert_hora']); ?></td>
				<td class="<?php echo e($apertura['apert_estado']=='1' ? 'text-danger':'text-success'); ?>"><?php echo e($apertura['apert_estado']=='1' ? 'Abierta': 'Cerrada'); ?></td>
				<td>
					<?php if($apertura['apert_estado']=='1'): ?>
					<a href="<?php echo e(route('cierre',$apertura)); ?>" class="btn btn-outline-info btn-sm" title="Cerrar Caja"><span class="fa fa-lock"></span></a>
					<?php else: ?>
					...
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	function setSurcursal(){
		var obj= document.getElementById("sucursal");
		if(obj.getAttribute('data-id')!= null)
			document.getElementById("selsucursal").value= obj.getAttribute('data-id');
	}
	setSurcursal();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\softsystem\resources\views/apertura.blade.php ENDPATH**/ ?>